import React, { Fragment } from 'react'

export const Footer = () => {
  return (
    <Fragment>
        <footer className="py-1">
            <p className="text-center mt-1">
                Ecoweb Store - 2022 - Mision TIC - Todos los derechos reservados
            </p>
        </footer>

    </Fragment>
  )
}